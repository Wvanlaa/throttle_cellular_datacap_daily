#!/bin/bash
cppython throttle_cellular_datacap_daily.py start